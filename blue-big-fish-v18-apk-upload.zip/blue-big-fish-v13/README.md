# Blue Big Fish V17 APK

V17 is based on the V16 daily-fireworks Android project and retains its existing game layout, sounds, tap animation, daily and lifetime counters, and home-screen widget.

## V17 daily appearance rules
- Daily taps 0–1,999: original maid appearance and the existing random phrase reactions.
- Daily taps 2,000 and above: switches to the supplied blue whale-maid appearance; random phrase reactions are hidden.
- At the next local-day rollover: daily count resets, original appearance and random phrase reactions return.
- Lifetime total remains cumulative.
- The same daily appearance and phrase rules apply to the Android app and home-screen widget.
- Fireworks milestone effects remain at each 1,000 daily taps.
